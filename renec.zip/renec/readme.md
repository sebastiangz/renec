# Guía de instalación e implementación del plugin RENEC

Este documento proporciona instrucciones detalladas para instalar y utilizar el plugin rediseñado de importación de competencias RENEC/CONOCER en Moodle 4.3.4+.

## Estructura del plugin

El plugin ha sido rediseñado con un enfoque por pasos, donde cada operación (crear marco, importar niveles, importar competencias) se realiza de forma independiente. Esta nueva versión resuelve los problemas anteriores al dividir el proceso en etapas claras y bien definidas.

```
local/renec/
├── classes/
│   └── form/
│       ├── create_framework_form.php     # Formulario para crear marco
│       ├── import_levels_form.php        # Formulario para importar niveles
│       └── import_competencies_form.php  # Formulario para importar competencias
├── db/
│   └── access.php                        # Definición de permisos
├── lang/
│   ├── en/
│   │   └── local_renec.php               # Traducciones en inglés
│   └── es/
│       └── local_renec.php               # Traducciones en español
├── create_framework.php                  # Página para crear marco
├── import_levels.php                     # Página para importar niveles
├── import_competencies.php               # Página para importar competencias
├── index.php                             # Página principal (menú)
├── lib.php                               # Funciones principales
└── version.php                           # Información de versión
```

## Requisitos previos

- Moodle versión 4.3.4 o superior
- Permisos de administrador en la plataforma Moodle
- Acceso para instalar plugins locales
- Archivos CSV del RENEC:
  - El archivo principal de competencias RENEC
  - Opcionalmente, el archivo de niveles (como el `2_levels_renec.csv` generado anteriormente)

## Pasos de instalación

1. **Preparar archivos**: Descargue todos los archivos del plugin.

2. **Crear la estructura de carpetas**:
   - Cree la carpeta `renec` dentro del directorio `local` de su instalación Moodle
   - Cree las subcarpetas necesarias: `classes/form`, `db`, `lang/en`, `lang/es`

3. **Copiar archivos**:
   - Coloque los archivos en las carpetas correspondientes según la estructura descrita arriba
   - Asegúrese de que todos los archivos tienen los permisos correctos (generalmente 644 para archivos y 755 para carpetas)

4. **Instalación del plugin**:
   - Acceda a su plataforma Moodle como administrador
   - Vaya a Administración del sitio > Notificaciones
   - Siga las instrucciones para completar la instalación del plugin

5. **Verificar la instalación**:
   - Vaya a Administración del sitio > Plugins > Plugins locales
   - Debería ver el plugin "Importador de competencias RENEC/CONOCER" en la lista
   - Asegúrese de que no hay errores o advertencias

## Uso del plugin

El plugin está diseñado para funcionar en tres pasos secuenciales:

### Paso 1: Crear marco de competencias

1. Acceda al plugin desde Administración del sitio > Plugins > Importador RENEC/CONOCER, o desde el bloque de navegación si está habilitado
2. En la página principal, seleccione "Paso 1: Crear marco de competencias"
3. Complete el formulario con:
   - **Nombre del marco**: Nombre que identifica el marco (ejemplo: "RENEC")
   - **ID del marco**: Identificador único (ejemplo: "RENEC-PRINCIPAL")
   - **Descripción**: Descripción detallada del marco
   - **Escala de competencias**: Seleccione una escala existente en su sistema
4. Haga clic en "Crear marco"
5. Si la creación es exitosa, será redirigido automáticamente al Paso 2

### Paso 2: Importar niveles

1. Seleccione el marco de competencias creado en el Paso 1 (o seleccione otro marco existente)
2. Tiene dos opciones:
   - **Opción A**: Marcar "Crear niveles predeterminados" para generar automáticamente los niveles 1-5 y Sin nivel
   - **Opción B**: Subir un archivo CSV con la estructura de niveles (como `2_levels_renec.csv`)
3. Si elige la Opción B, puede configurar opciones avanzadas como codificación y delimitador
4. Haga clic en "Importar niveles"
5. Si la importación es exitosa, será redirigido automáticamente al Paso 3

### Paso 3: Importar competencias

1. Seleccione el marco de competencias donde ya ha importado los niveles
2. Suba el archivo CSV con las competencias RENEC
3. Configure las opciones según sus necesidades:
   - **Sobrescribir competencias existentes**: Actualiza competencias si ya existen
   - **Crear niveles faltantes**: Crea automáticamente niveles no existentes
4. En opciones avanzadas, ajuste la codificación y el delimitador si es necesario
5. Haga clic en "Importar competencias"
6. Se mostrará un informe detallado de la importación

## Verificación y uso posterior

1. **Verificar el marco de competencias**:
   - Vaya a Administración del sitio > Competencias > Marcos de competencias
   - Seleccione el marco RENEC creado
   - Debería ver la estructura jerárquica: Marco > Niveles > Competencias individuales

2. **Asociar competencias a cursos**:
   - Desde un curso, vaya a Administración del curso > Competencias
   - Añada competencias RENEC al curso
   - Configure los criterios de evaluación según sus necesidades

3. **Evaluar competencias**:
   - Las competencias importadas pueden ser evaluadas y seguidas como cualquier otra competencia en Moodle
   - Se pueden generar informes y seguimiento de progreso

## Solución de problemas

### Errores comunes

1. **Problema de codificación en archivos CSV**:
   - Si ve caracteres extraños, intente ajustar la codificación en las opciones avanzadas
   - Pruebe diferentes encodings como UTF-8, CP1252 o ISO-8859-1

2. **Error al crear el marco de competencias**:
   - Verifique que la escala seleccionada existe y está correctamente configurada
   - Asegúrese de que el ID del marco no está duplicado

3. **Error en la importación de niveles**:
   - Verifique que el CSV de niveles tiene la estructura correcta
   - Asegúrese de que las columnas requeridas están presentes y correctamente nombradas

4. **Error en la importación de competencias**:
   - Verifique que el CSV de competencias contiene todas las columnas requeridas
   - Asegúrese de que los niveles referenciados existen en el marco

### Registro de errores

Para obtener más información sobre errores:

1. Habilite el modo depuración en Moodle: 
   - Administración del sitio > Desarrollo > Configuración de depuración
   - Establezca "Mostrar mensajes de depuración" a "DESARROLLADOR"

2. Consulte los registros de Moodle:
   - Administración del sitio > Informes > Registros

## Personalización

Si necesita ajustar el plugin a sus necesidades específicas:

1. **Modificar los niveles predeterminados**:
   - Edite la función `local_renec_create_default_levels` en `lib.php`

2. **Cambiar el formato de las competencias importadas**:
   - Ajuste la función `local_renec_import_competencies_csv` en `lib.php`

3. **Añadir campos adicionales**:
   - Modifique los formularios en la carpeta `classes/form`
   - Actualice los archivos de idioma para incluir nuevas cadenas
